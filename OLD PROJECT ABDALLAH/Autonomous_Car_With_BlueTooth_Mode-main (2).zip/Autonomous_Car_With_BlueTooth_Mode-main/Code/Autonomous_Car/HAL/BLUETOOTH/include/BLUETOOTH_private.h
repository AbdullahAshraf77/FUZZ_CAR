/*
 * BLUETOOTH_private.h
 *
 * Created: 09-Oct-23 3:09:41 PM
 *  Author: M5_Autonomous_Car_TEAM
 */ 


#ifndef BLUETOOTH_PRIVATE_H_
#define BLUETOOTH_PRIVATE_H_





#endif /* BLUETOOTH_PRIVATE_H_ */