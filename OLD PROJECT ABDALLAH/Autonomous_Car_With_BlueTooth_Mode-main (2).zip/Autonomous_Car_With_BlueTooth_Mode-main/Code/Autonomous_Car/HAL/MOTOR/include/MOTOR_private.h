/*
 * MOTOR_private.h
 *
 * Created: 11-Dec-23 12:00:57 AM
 *  Author: M5_Autonomous_Car_TEAM
 */ 


#ifndef MOTOR_PRIVATE_H_
#define MOTOR_PRIVATE_H_





#endif /* MOTOR_PRIVATE_H_ */