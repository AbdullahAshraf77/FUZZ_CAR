/*
 * BUZZER_private.h
 *
 * Created: 18-Sep-23 9:45:33 PM
 *  Author: M5_Autonomous_Car_TEAM
 */ 


#ifndef BUZZER_PRIVATE_H_
#define BUZZER_PRIVATE_H_





#endif /* BUZZER_PRIVATE_H_ */