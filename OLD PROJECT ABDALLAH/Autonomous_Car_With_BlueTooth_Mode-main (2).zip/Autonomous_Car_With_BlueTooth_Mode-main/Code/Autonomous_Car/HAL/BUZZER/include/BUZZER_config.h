/*
 * BUZZER_config.h
 *
 * Created: 18-Sep-23 9:45:19 PM
 *  Author: M5_Autonomous_Car_TEAM
 */ 


#ifndef BUZZER_CONFIG_H_
#define BUZZER_CONFIG_H_


#define BUZZER_PORT    DIO_PORTA
#define BUZZER_PIN     DIO_PIN5


#endif /* BUZZER_CONFIG_H_ */