/*
 * BUTTON_config.h
 *
 * Created: 09-Sep-23 12:19:48 AM
 *  Author: M5_Autonomous_Car_TEAM
 */ 


#ifndef BUTTON_CONFIG_H_
#define BUTTON_CONFIG_H_

#define BUTTON_MODE_PORT      DIO_PORTD
#define BUTTON_MODE_PIN       DIO_PIN2



#endif /* BUTTON_CONFIG_H_ */