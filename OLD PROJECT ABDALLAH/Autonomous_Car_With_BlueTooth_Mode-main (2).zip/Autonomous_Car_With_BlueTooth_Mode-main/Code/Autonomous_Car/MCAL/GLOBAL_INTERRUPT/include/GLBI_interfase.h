/*
 * GLBI_interfase.h
 *
 * Created: 09-Sep-23 5:59:09 PM
 *  Author:M5_Autonomous_Car_TEAM
 */ 


#ifndef GLBI_INTERFASE_H_
#define GLBI_INTERFASE_H_


void GLBI_Enable               ();


#endif /* GLBI_INTERFASE_H_ */