/*
 * GLBI_private.h
 *
 * Created: 09-Sep-23 6:00:23 PM
 *  Author: M5_Autonomous_Car_TEAM
 */ 


#ifndef GLBI_PRIVATE_H_
#define GLBI_PRIVATE_H_

#define SREG            (*(volatile u8*)0x5f)
#define I               7



#endif /* GLBI_PRIVATE_H_ */