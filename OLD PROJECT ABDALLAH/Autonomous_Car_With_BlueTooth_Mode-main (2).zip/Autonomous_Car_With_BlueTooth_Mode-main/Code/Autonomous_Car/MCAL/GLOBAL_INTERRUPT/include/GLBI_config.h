/*
 * GLBI_config.h
 *
 * Created: 11-Dec-23 12:05:04 AM
 *  Author: M5_Autonomous_Car_TEAM
 */ 


#ifndef GLBI_CONFIG_H_
#define GLBI_CONFIG_H_





#endif /* GLBI_CONFIG_H_ */