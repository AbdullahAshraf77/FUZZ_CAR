/*
 * TIMER1_config.h
 *
 * Created: 22-Sep-23 8:34:25 AM
 *  Author: M5_Autonomous_Car_TEAM
 */ 


#ifndef TIMER1_CONFIG_H_
#define TIMER1_CONFIG_H_


//#define SERVO_FREQUANCE 4999
//#define SERVO_DUTYCYLE  499     // 499 -> +90 || 374 -> 0 || 249 -> -90


#endif /* TIMER1_CONFIG_H_ */